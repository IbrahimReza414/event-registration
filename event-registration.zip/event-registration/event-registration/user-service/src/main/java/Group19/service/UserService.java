package Group19.service;

import Group19.model.EventUser;
import Group19.repository.EventUserRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final EventUserRepository eventUserRepository;
    private final RestTemplate restTemplate;

    public UserService(EventUserRepository eventUserRepository, RestTemplate restTemplate) {
        this.eventUserRepository = eventUserRepository;
        this.restTemplate = restTemplate;
    }

    // Create a new user
    public EventUser createUser(EventUser eventUser) {
        return eventUserRepository.save(eventUser);
    }

    // Get a user by ID
    public EventUser getUserById(Long userId) {
        return eventUserRepository.findById(userId).orElse(null);
    }

    // Update a user by ID
    public EventUser updateUser(Long userId, EventUser updatedUser) {
        Optional<EventUser> existingUser = eventUserRepository.findById(userId);
        if (existingUser.isPresent()) {
            EventUser user = existingUser.get();
            user.setEmail(updatedUser.getEmail());
            user.setName(updatedUser.getName());
            user.setPassword(updatedUser.getPassword());
            user.setPhone(updatedUser.getPhone());
            return eventUserRepository.save(user);
        }
        return null;
    }

    // Delete a user by ID
    public String deleteUser(Long userId) {
        if (eventUserRepository.existsById(userId)) {
            eventUserRepository.deleteById(userId);
            return "User deleted successfully.";
        }
        return "User not found.";
    }

    // Get all users (optional)
    public List<EventUser> getAllUsers() {
        return eventUserRepository.findAll();
    }

    // Register user for an event by calling EventService
    public String registerUserForEvent(Long userId, Long eventId) {
        Optional<EventUser> user = eventUserRepository.findById(userId);
        if (user.isPresent()) {
            String eventServiceUrl = "http://localhost:8081/events/registerUser?userId=" + userId + "&eventId=" + eventId;
            return restTemplate.postForObject(eventServiceUrl, null, String.class);
        }
        return "User not found!";
    }

    // View user's profile along with registered events
    public EventUser viewUserProfile(Long userId) {
        Optional<EventUser> user = eventUserRepository.findById(userId);
        if (user.isPresent()) {
            EventUser eventUser = user.get();
            String eventServiceUrl = "http://localhost:8081/events/registeredEvents?userId=" + userId;
            List<?> registeredEvents = restTemplate.getForObject(eventServiceUrl, List.class);
            eventUser.setRegisteredEvents(registeredEvents); // assuming EventUser has a registeredEvents field
            return eventUser;
        }
        return null;
    }
}
