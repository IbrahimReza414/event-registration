package Group19.repository;

import Group19.model.EventUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.client.RestTemplate;


public interface EventUserRepository extends JpaRepository<EventUser, Long> {

}
