package Group19.controller;

import Group19.model.EventUser;
import Group19.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;


import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // Create a new user
    @PostMapping
    public ResponseEntity<EventUser> createUser(@RequestBody EventUser eventUser) {
        EventUser createdUser = userService.createUser(eventUser);
        return ResponseEntity.ok(createdUser);
    }

    // Get a user by ID
    @GetMapping("/{userId}")
    public ResponseEntity<EventUser> getUserById(@PathVariable Long userId) {
        EventUser eventUser = userService.getUserById(userId);
        return ResponseEntity.ok(eventUser);
    }

    // Update a user by ID
    @PutMapping("/{userId}")
    public ResponseEntity<EventUser> updateUser(@PathVariable Long userId, @RequestBody EventUser updatedUser) {
        EventUser eventUser = userService.updateUser(userId, updatedUser);
        return ResponseEntity.ok(eventUser);
    }

    // Delete a user by ID
    @DeleteMapping("/{userId}")
    public ResponseEntity<String> deleteUser(@PathVariable Long userId) {
        String result = userService.deleteUser(userId);
        return ResponseEntity.ok(result);
    }

    // Register a user for an event (new use case)
    @PostMapping("/{userId}/register/{eventId}")
    public ResponseEntity<String> registerForEvent(@PathVariable Long userId, @PathVariable Long eventId) {
        String result = userService.registerUserForEvent(userId, eventId);
        return ResponseEntity.ok(result);
    }

    // View user profile and registered events (new use case)
    @GetMapping("/{userId}/profile")
    public ResponseEntity<EventUser> getUserProfile(@PathVariable Long userId) {
        EventUser eventUser = userService.viewUserProfile(userId);
        if (eventUser != null) {
            return ResponseEntity.ok(eventUser);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Get all users (optional if needed)
    @GetMapping
    public ResponseEntity<List<EventUser>> getAllUsers() {
        List<EventUser> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }
}
