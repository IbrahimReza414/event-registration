Event Registration System

This project contains three standalone microservices: User Service, Admin Service, and Event Service. Each service operates independently, and they communicate through their own APIs.
Microservices

    User Service: Handles user operations (create, update, delete users, view user profiles, and register for events).
    Admin Service: Manages admin operations (create, update, delete admins, create and delete events).
    Event Service: Manages event-related operations (future use cases to be defined).

Ensure you have the following installed:

    Java 17+
    Maven 3+
    Postman or curl for testing API endpoints

How to Run the Application

Each service needs to run on a different port. You will have to run the microservices independently.

1.Clone repository

    git clone <repository_url>
    cd event-registration

2.Build and run the User Service:

    cd user-service
    mvn clean install
    mvn spring-boot:run

3.Build and run the Admin Service:

    cd ../admin-service
    mvn clean install
    mvn spring-boot:run

4.Build and run the Event Service:

    cd ../event-service
    mvn clean install
    mvn spring-boot:run

Each service will be running on the following ports:

    User Service: http://localhost:8081
    Admin Service: http://localhost:8082
    Event Service: http://localhost:8083

Testing the Services

Create a user:

    curl -X POST http://localhost:8081/users -H "Content-Type: application/json" \
    -d '{"email": "test@example.com", "name": "Test User", "password": "password123", "phone": "1234567890"}'

Update a user:

    curl -X PUT http://localhost:8081/users/1 -H "Content-Type: application/json" \
    -d '{"email": "updated@example.com", "name": "Updated User", "password": "newpassword123", "phone": "9876543210"}'

Delete a user:

    curl -X DELETE http://localhost:8081/users/1

View a user profile:

    curl -X GET http://localhost:8081/users/1

Create an admin:

    curl -X POST http://localhost:8082/admins -H "Content-Type: application/json" \
    -d '{"email": "admin@example.com", "name": "Admin User", "password": "adminpass123"}'

Update an admin:

    curl -X PUT http://localhost:8082/admins/1 -H "Content-Type: application/json" \
    -d '{"email": "updatedadmin@example.com", "name": "Updated Admin", "password": "newadminpass"}'

Delete an admin:

    curl -X DELETE http://localhost:8082/admins/1

Create an event (admin action):

    curl -X POST http://localhost:8082/events -H "Content-Type: application/json" \
    -d '{"title": "Tech Conference", "description": "A great tech event", "date": "2024-12-01T10:00:00", "location": "New York", "availableTickets": 150, "ticketPrice": 100}'

Delete an event (admin action):

    curl -X DELETE http://localhost:8082/events/1